package uniandes.dpoo.aerolinea.persistencia;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;

import org.json.JSONArray;
import org.json.JSONObject;

import uniandes.dpoo.aerolinea.exceptions.AeropuertoDuplicadoException;
import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea {
	
	@Override
	public void cargarAerolinea(String archivo, Aerolinea aerolinea) throws IOException, InformacionInconsistenteException {
		try {
		String jsonCompleto = new String( Files.readAllBytes( new File( archivo ).toPath( ) ) );
        JSONObject raiz = new JSONObject( jsonCompleto );
        
        cargarVuelos( aerolinea, raiz.getJSONArray( "vuelos" ) );
        cargarAviones( aerolinea, raiz.getJSONArray( "aviones" ) );
        cargarRutas(aerolinea, raiz.getJSONArray("rutas"));
		}
		catch(IOException e) {
			System.out.println("Utilice bien la consola/input invalido.");
			
		}
		catch(InformacionInconsistenteException e) {
			System.out.println(e.getMessage());
		}
	}



	private void cargarRutas(Aerolinea aerolinea, JSONArray jRutas) throws InformacionInconsistenteException{
		int numRutas = jRutas.length( );
        for( int i = 0; i < numRutas; i++ )
        {
            JSONObject ruta = jRutas.getJSONObject( i );
            
            String codigo = ruta.getString("codigo");
            
            if (aerolinea.getRuta(codigo)==null) {
            	String horaLlegada = ruta.getString("horaLlegada");
            	String horaSalida = ruta.getString("horaSalida");
            	JSONObject aeropuertoOrigen = ruta.getJSONObject("aeropuertoOrigen");
            	
            	JSONObject aeropuertoDestino = ruta.getJSONObject("aeropuertoDestino");
            	
            	String nombreOrigen = aeropuertoOrigen.getString("nombre");
            	String codOrigen = aeropuertoOrigen.getString("codigo");
            	String nombreCiudadOrigen = aeropuertoOrigen.getString("ciudad");
            	double latitudOrigen = aeropuertoOrigen.getDouble("latitud");
            	double longitudOrigen = aeropuertoOrigen.getDouble("longitud");
            	
            	String nombreDestino = aeropuertoDestino.getString("nombre");
            	String codDestino = aeropuertoDestino.getString("codigo");
            	String nombreCiudadDestino = aeropuertoDestino.getString("ciudad");
            	double latitudDestino = aeropuertoDestino.getDouble("latitud");
            	double longitudDestino = aeropuertoDestino.getDouble("longitud");
            	
            	try {
            		Aeropuerto origen = new Aeropuerto(nombreOrigen, codOrigen, nombreCiudadOrigen, latitudOrigen, longitudOrigen);
            		Aeropuerto destino = new Aeropuerto(nombreDestino, codDestino, nombreCiudadDestino, latitudDestino, longitudDestino);
            		Ruta rutaNueva = new Ruta(origen, destino, horaLlegada, horaSalida, codigo);
            		aerolinea.agregarRuta(rutaNueva);
            	}
            	
            	catch (AeropuertoDuplicadoException e) {
            		throw new InformacionInconsistenteException(e.getMessage());
            	}
            	
            }
            
            
        }
		
	}

	private void cargarAviones(Aerolinea aerolinea, JSONArray jAviones) throws InformacionInconsistenteException {
		int numAviones = jAviones.length( );
        for( int i = 0; i < numAviones; i++ )
        {
            JSONObject avion = jAviones.getJSONObject( i );
            String nombre = avion.getString("nombre");
            int capacidad = avion.getInt("capacidad");
            
            if(aerolinea.getAvionPorNombre(nombre)==null) {
            	Avion nuevoAvion = new Avion(nombre, capacidad);
            	aerolinea.agregarAvion(nuevoAvion);
            }
            else {
            	throw new InformacionInconsistenteException("El avion "+nombre+" ya se encuentra registrado en la aerolinea.");
            }
        }
        
		
	}

	private void cargarVuelos(Aerolinea aerolinea, JSONArray jVuelos) throws InformacionInconsistenteException {
		int numVuelos = jVuelos.length( );
        for( int i = 0; i < numVuelos; i++ )
        {
            JSONObject vuelo = jVuelos.getJSONObject( i );
            String codigoRuta = vuelo.getString("ruta");
            String fecha = vuelo.getString("fecha");
            String nombreAvion = vuelo.getString("nombreAvion");
            
            if (aerolinea.getRuta(codigoRuta)==null) {
            	throw new InformacionInconsistenteException("No existe la ruta con codigo "+codigoRuta+" en la aerolinea");
            }
            else if (aerolinea.getAvionPorNombre(nombreAvion)==null) {
            	throw new InformacionInconsistenteException("No existe el avion con nombre "+nombreAvion+" en la aerolinea");
            }
            else {
            	
            	try {
            		aerolinea.programarVuelo(fecha, codigoRuta, nombreAvion);
            		
            	}
            	
            	catch (Exception e) {
            		System.out.println(e.getMessage());
            	}
            }
        }
        
		
	}

	@Override
	public void salvarAerolinea(String archivo, Aerolinea aerolinea) {
		JSONObject jobject = new JSONObject( );


        salvarVuelos( aerolinea, jobject );

        salvarAviones( aerolinea, jobject );
        
        salvarRutas( aerolinea, jobject );

        // Escribir la estructura JSON en un archivo
        PrintWriter pw;
		try {
			pw = new PrintWriter( archivo );
	        jobject.write( pw, 2, 0 );
	        pw.close( );
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Hay un error con el nombre de archivo ingresado");
		}

	}



	private void salvarRutas(Aerolinea aerolinea, JSONObject jobject) {
		JSONArray jRutas = new JSONArray();
		
		for(Ruta ruta: aerolinea.getRutas()) {
			
			JSONObject jRuta = new JSONObject();
			JSONObject jOrigen = new JSONObject();
			JSONObject jDestino = new JSONObject();
			
			jOrigen.put("nombre", ruta.getOrigen().getNombre());
			jOrigen.put("codigo", ruta.getOrigen().getCodigo());
			jOrigen.put("ciudad",ruta.getOrigen().getNombreCiudad());
			jOrigen.put("latitud", ruta.getOrigen().getLatitud());
			jOrigen.put("longitud", ruta.getOrigen().getLatitud());
			
			jDestino.put("nombre", ruta.getDestino().getNombre());
			jDestino.put("codigo", ruta.getDestino().getCodigo());
			jDestino.put("ciudad",ruta.getDestino().getNombreCiudad());
			jDestino.put("latitud", ruta.getDestino().getLatitud());
			jDestino.put("longitud", ruta.getDestino().getLatitud());
			
			jRuta.put("aeropuertoDestino", jDestino);
			jRuta.put("aeropuertoOrigen", jOrigen);
			
			jRuta.put("codigo", ruta.getCodigoRuta());
			jRuta.put("horaLlegada", ruta.getHoraLlegada());
			jRuta.put("horaSalida", ruta.getHoraSalida());
		}
		
	}



	private void salvarAviones(Aerolinea aerolinea, JSONObject jobject) {
		JSONArray jAviones = new JSONArray();
		for (Avion avion: aerolinea.getAviones()) {
			JSONObject jAvion = new JSONObject();
			
			jAvion.put("nombre", avion.getNombre());
			jAvion.put("capacidad", avion.getCapacidad());
			
			jAviones.put(jAvion);
		}
		
		jobject.put("aviones", jAviones);
		
	}



	private void salvarVuelos(Aerolinea aerolinea, JSONObject jobject) {
		// TODO Auto-generated method stub
		
	}
}
