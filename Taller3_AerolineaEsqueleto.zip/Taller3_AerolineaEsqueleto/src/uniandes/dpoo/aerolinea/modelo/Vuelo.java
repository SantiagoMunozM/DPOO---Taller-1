package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.GeneradorTiquetes;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
	
	private String fecha;
	
	private Ruta ruta;
	
	private Avion avion;
	
	private Map<String, Tiquete> tiquetes;
	
	
	public Vuelo (Ruta pRuta, String pFecha, Avion pAvion) {
		this.avion = pAvion;
		this.ruta = pRuta;
		this.fecha = pFecha;
		this.tiquetes = new HashMap<String, Tiquete>();
		
		
	}
	
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) throws VueloSobrevendidoException {
		
		int capacidad = this.avion.getCapacidad();
		
		int tiquetesVendidos = this.tiquetes.size();
		
		if (tiquetesVendidos +cantidad>capacidad) {
			throw new VueloSobrevendidoException (this);
		}
		
		else {
		
		int tarifa = calculadora.calcularTarifa(this, cliente);
		Map<String, Tiquete> mapa = this.tiquetes;
		
		for (int i = 0; i<cantidad; i++) {
			Tiquete nuevoTiquete = GeneradorTiquetes.generarTiquete(this, cliente, tarifa);
			GeneradorTiquetes.registrarTiquete(nuevoTiquete);
			
			String cod = nuevoTiquete.getCodigo();
			
			
			
			mapa.put(cod, nuevoTiquete);
			
			cliente.agregarTiquete(nuevoTiquete);
		}
		
		int total = tarifa*cantidad;
		
		return total;
		
		}
		
	}
	
	@Override
	
	public boolean equals(Object obj) {
		boolean rta = true;
		if (obj == null) {
			rta = false;
		}
		else if (obj.getClass() != this.getClass()) {
			rta = false;
		}
		else {
			Vuelo otroVuelo = (Vuelo) obj;
			boolean avion = this.getAvion() == otroVuelo.getAvion();
			boolean ruta = this.getRuta().equals(otroVuelo.getRuta());
			boolean fecha = this.getFecha().equals(otroVuelo.getFecha());
			boolean tiquetes = this.getTiquetes().equals(otroVuelo.getTiquetes());
			if (avion == false || ruta == false || fecha == false || tiquetes == false) {
				rta = false;
			}
			
		}
		
		return rta;
		
		
	}

	public Collection<Tiquete> getTiquetes() {
		return tiquetes.values();
	}


	public Ruta getRuta() {
		return ruta;
	}



	public Avion getAvion() {
		return avion;
	}


	public String getFecha() {
		return fecha;
	}



}
