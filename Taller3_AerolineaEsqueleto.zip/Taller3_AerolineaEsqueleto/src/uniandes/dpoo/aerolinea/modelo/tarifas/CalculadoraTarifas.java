package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {
	
	protected static double IMPUESTO = 0.28;
	
	public CalculadoraTarifas() {
		
	}
	
	
	public int calcularTarifa (Vuelo vuelo, Cliente cliente) {
		
		int costoBase = calcularCostoBase(vuelo, cliente);
		double porcentajeDescuento = calcularPorcentajeDescuento(cliente);
		
		int costoConDescuento = (int) Math.round(costoBase*(1-porcentajeDescuento));
		
		int impuestos = calcularValorImpuestos(costoConDescuento);
		
		int costoFinal = costoConDescuento + impuestos;
		
		
		
		return costoFinal;
	}
	
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	
	protected int calcularDistanciaVuelo(Ruta ruta) {
		
		Aeropuerto origen = ruta.getOrigen();
		Aeropuerto destino = ruta.getDestino();
		
		int distancia = Aeropuerto.calcularDistancia(origen, destino);
		
		return distancia;
	}
	
	protected int calcularValorImpuestos (int costoBase) {
		int impuestos = (int) Math.round(costoBase*IMPUESTO);
		
		return impuestos;
	}
}
