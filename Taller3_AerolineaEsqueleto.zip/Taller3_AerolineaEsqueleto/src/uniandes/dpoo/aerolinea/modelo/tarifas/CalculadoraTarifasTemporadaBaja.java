package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas{
	
	protected int COSTO_POR_KM_NATURAL = 600;
	protected int COSTO_POR_KM_CORPORATIVO = 900;
	protected double DESCUENTO_PEQ = 0.02;
	protected double DESCUENTO_MEDIANAS = 0.1;
	protected double DESCUENTO_GRANDES = 0.2;
	
	public CalculadoraTarifasTemporadaBaja(){
		super();
	}
	
	public double calcularPorcentajeDescuento(Cliente cliente) {
		String tipoCliente = cliente.getTipoCliente();
		double descuento = 0;
		if (tipoCliente.equals("Natural")==false){
			
			descuento = descuentoCorporativo((ClienteCorporativo) cliente);
		}
		
		return descuento;
		
	}
		
	public double descuentoCorporativo (ClienteCorporativo cliente) {
		int tamano_compania = cliente.getTamanoEmpresa();
		double descuento = 0;
		if (tamano_compania == 1) {
			descuento = getDESCUENTO_GRANDES();

			}
		else if (tamano_compania == 2) {
			descuento = getDESCUENTO_MEDIANAS();
			
		}
		
		else {
			descuento = getDESCUENTO_PEQ();
			
		}
		
		return descuento;
	}
	
	public int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		Ruta ruta = vuelo.getRuta();
		int distancia = this.calcularDistanciaVuelo(ruta);
		int costoKM = 0;
		String tipo = cliente.getTipoCliente();
		if (tipo.equals("Natural")) {
			costoKM = this.getCOSTO_POR_KM_NATURAL();
			
		}
		else {
			costoKM = this.getCOSTO_POR_KM_CORPORATIVO();
		}
		
		int costoBase = distancia*costoKM;
		
		return costoBase;
	}

	public int getCOSTO_POR_KM_NATURAL() {
		return COSTO_POR_KM_NATURAL;
	}

	public int getCOSTO_POR_KM_CORPORATIVO() {
		return COSTO_POR_KM_CORPORATIVO;
	}

	public double getDESCUENTO_PEQ() {
		return DESCUENTO_PEQ;
	}

	public double getDESCUENTO_MEDIANAS() {
		return DESCUENTO_MEDIANAS;
	}

	public double getDESCUENTO_GRANDES() {
		return DESCUENTO_GRANDES;
	}
	
	
}
