package uniandes.dpoo.aerolinea.modelo;

public class Avion {
	
	private String nombre;
	
	private int capacidad;
	
	public Avion(String pNombre, int pCapacidad) {
		
		
		this.capacidad = pCapacidad;
		this.nombre = pNombre;
	}
	


	public String getNombre() {
		return nombre;
	}

	public int getCapacidad() {
		return capacidad;
	}


}