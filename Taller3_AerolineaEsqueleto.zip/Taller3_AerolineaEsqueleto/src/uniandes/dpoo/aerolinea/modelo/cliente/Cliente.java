package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {
	
	private List<Tiquete> tiquetesSinUsar;
	private List<Tiquete> tiquetesUsados;

	
	public Cliente () {
		this.tiquetesSinUsar = new ArrayList<Tiquete>();
		this.tiquetesUsados = new ArrayList<Tiquete>();

		
		
		
	}
	
	public abstract String getTipoCliente();
	
	public abstract String getIdentificador();
	
	public void agregarTiquete (Tiquete tiquete) {
		
		this.tiquetesSinUsar.add(tiquete);
		
	}
	
	public int calcularValortotalTiquetes() {
		
		List<Tiquete> sinUsar = getTiquetesSinUsar();
		List<Tiquete> Usados = getTiquetesUsados();
		
		int total = 0;
		
		for (Tiquete tiq: sinUsar) {
			int tarifa = tiq.getTarifa();
			total+=tarifa;
		}
		
		for (Tiquete tiq: Usados) {
			int tarifa = tiq.getTarifa();
			total+=tarifa;
		}
		
		return total;
				
	}
	
	public void usarTiquetes (Vuelo vuelo) {
		
		List<Tiquete> sinUsar = getTiquetesSinUsar();
		List<Tiquete> usados = getTiquetesUsados();
		
		List<Tiquete> sinUsarActualizado = new ArrayList<Tiquete>();
		for (Tiquete tiq: sinUsar) {
			Vuelo vueloTiq = tiq.getVuelo();
			if (vuelo.equals(vueloTiq)){
				usados.add(tiq);	
			}
			else {
				sinUsarActualizado.add(tiq);
			}
		}
		
		setTiquetesSinUsar(sinUsarActualizado);
		
	}

	public void setTiquetesSinUsar(List<Tiquete> tiquetesSinUsar) {
		this.tiquetesSinUsar = tiquetesSinUsar;
	}

	public List<Tiquete> getTiquetesSinUsar() {
		return tiquetesSinUsar;
	}

	public List<Tiquete> getTiquetesUsados() {
		return tiquetesUsados;
	}

}
