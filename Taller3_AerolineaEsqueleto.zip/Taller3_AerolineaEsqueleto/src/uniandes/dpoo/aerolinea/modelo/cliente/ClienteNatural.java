package uniandes.dpoo.aerolinea.modelo.cliente;

public class ClienteNatural extends Cliente {
	public static String NATURAL = "Natural";
	private static int numClientesNat=1;
	
	private String nombre;
	private int posCliente;
	
	public ClienteNatural(String nombre) {
		this.nombre = nombre;
		this.posCliente = numClientesNat;
		numClientesNat++;
	}
	
	public String getIdentificador() {
		String id = getNombre()+Integer.toString(getPosCliente());
		return id;
	}
	
	public String getTipoCliente() {
		return NATURAL;
	}

	public String getNombre() {
		return nombre;
	}

	public int getPosCliente() {
		return posCliente;
	}




	
}
