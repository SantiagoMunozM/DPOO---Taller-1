package uniandes.dpoo.swing.interfaz.agregar;

import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class PanelEditarRestaurante extends JPanel
{
    /**
     * El campo para que el usuario ingrese el nombre del restaurante
     */
    private JTextField txtNombre;

    /**
     * Un selector (JComboBox) para que el usuario seleccione la calificación (1 a 5) del restaurante
     */
    private JComboBox<String> cbbCalificacion;

    /**
     * Un selector (JComboBox) para que el usuario indique si ya visitó el restaurante o no
     */
    private JComboBox<String> cbbVisitado;

    public PanelEditarRestaurante( )
    {
    	super();
    	this.setLayout(new GridLayout(3, 1));
        // Crea el campo para el nombre con una etiqueta al frente
        // TODO completar
    	JPanel panelNombre = new JPanel();
    	panelNombre.setLayout(new FlowLayout(FlowLayout.LEFT));
    	this.txtNombre = new JTextField(10);
    	txtNombre.setEnabled(true);
    	JLabel etiquetaTxt = new JLabel("Nombre");
    	
    	panelNombre.add(etiquetaTxt);
    	panelNombre.add(txtNombre);
    	

        // Crea el selector para la calificación con una etiqueta al frente
        // TODO completar
    	JPanel panelCalificacion = new JPanel();
    	panelCalificacion.setLayout(new FlowLayout(FlowLayout.LEFT));
    	String[] calificaciones = {"1", "2", "3", "4", "5"};
    	this.cbbCalificacion = new JComboBox<String>(calificaciones);
    	JLabel etiquetaCalif = new JLabel("Calificación");
    	panelCalificacion.add(etiquetaCalif);
    	panelCalificacion.add(cbbCalificacion);
    	

        // Crea el selector para indicar si ya ha sido visitado, con una etiqueta al frente
        // TODO completar
    	JPanel panelVisitado = new JPanel();
    	panelVisitado.setLayout(new FlowLayout(FlowLayout.LEFT));
    	String[] opcionVisitado = {"Si", "No"};
    	this.cbbVisitado = new JComboBox<String>(opcionVisitado);
    	JLabel etiquetaVisitado = new JLabel("Visitado");
    	panelVisitado.add(etiquetaVisitado);
    	panelVisitado.add(cbbVisitado);

        // Agregar todos los elementos al panel
    	
    	this.add(panelNombre);
    	this.add(panelCalificacion);
    	this.add(panelVisitado);
    	this.setVisible(true);
    	// TODO completar

    }

    /**
     * Indica si en el selector se seleccionó la opción que dice que el restaurante fue visitado
     * @return
     */
    public boolean getVisitado( )
    {
        // TODO completar
    	String opcion = (String) cbbVisitado.getSelectedItem();
    	boolean rta;
    	
    	if (opcion.equals("Si")) {
    		rta = true;
    	}
    	else {
    		rta = false;
    	}
        return rta;
    }

    /**
     * Indica la calificación marcada en el selector
     * @return
     */
    public int getCalificacion( )
    {
        String calif = ( String )cbbCalificacion.getSelectedItem( );
        return Integer.parseInt( calif );
    }

    /**
     * Indica el nombre digitado para el restaurante
     * @return
     */
    public String getNombre( )
    {
        // TODO completar
    	try {
    	String nombre = (String) txtNombre.getText();
    	
        return nombre;
    	}
    	
    	catch (NullPointerException e) {
    		return "";
    	}
    }
}
