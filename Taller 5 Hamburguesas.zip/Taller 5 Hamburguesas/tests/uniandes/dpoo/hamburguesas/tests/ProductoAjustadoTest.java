package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoAjustadoTest {
	
	private ProductoAjustado productoAjustado;
	private ProductoMenu productoBase;
	
	
	@BeforeEach
	public void setUp() {
		
		productoBase = new ProductoMenu ("Todoterreno", 30000);
		productoAjustado = new ProductoAjustado(productoBase);
	
	}
	
	@Test
	@DisplayName ("Prueba Constructor")
	public void pruebaConstructor(){
		
		assertEquals(productoAjustado.getNombre(), "Todoterreno","Nombre guardado incorrectamente");
		assertEquals(productoAjustado.getPrecio(), 30000, "Precio inicial incorrecto");
		
	}
	@Test
	@DisplayName ("Prueba Cambio de Precio Agregar Ingrediente")
	public void pruebaPrecioAjustadoAgregarIngrediente() {
		
		Ingrediente lechuga = new Ingrediente("Lechuga", 2000);
		productoAjustado.agregarIngrediente(lechuga);
		
		assertEquals(productoAjustado.getPrecio(), 32000, "Precio incorrecto con ingredientes adicionales");
		
	}
	
	@Test 
	@DisplayName ("Prueba Mantener Precio Eliminar Ingrediente")
	
	public void pruebaPrecioEliminarIngrediente(){
		
		Ingrediente salsaTomate = new Ingrediente("Salsa de Tomate", 500);
		productoAjustado.eliminarIngrediente(salsaTomate);
		
		assertEquals(productoAjustado.getPrecio(), 30000, "Eliminar ingredientes no debe cambiar el precio");
		
		
	}
	
	@Test
	@DisplayName("Prueba Generar Factura")
	
	public void pruebaFactura() {
		Ingrediente lechuga = new Ingrediente("Lechuga", 2000);
		productoAjustado.agregarIngrediente(lechuga);
		Ingrediente salsaTomate = new Ingrediente("Salsa de Tomate", 500);
		productoAjustado.eliminarIngrediente(salsaTomate);
		
		String facturaGenerada = productoAjustado.generarTextoFactura();
		String facturaEsperada = "Todoterreno\n    +Lechuga\n                2000\n"+
								 "    -Salsa de Tomate\n"+ 
								 "            32000\n";
		
		assertEquals(facturaGenerada, facturaEsperada, "Factura generada incorrectamente");
	}
}
