package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.excepciones.HamburguesaException;
import uniandes.dpoo.hamburguesas.excepciones.IngredienteRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.NoHayPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoFaltanteException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;

public class RestauranteTest {
	
	private Restaurante restaurante;
	
	@BeforeEach
	public void setUp() {
		restaurante = new Restaurante();
	}
	
	@Test
	@DisplayName("Prueba Carga Archivos .txt")
	public void probarCarga() {
		
		File ingredientes = new File("./data/ingredientes.txt");	
		File combos = new File("./data/combos.txt");	
		File menu= new File("./data/menu.txt");	
		
		try {
			restaurante.cargarInformacionRestaurante(ingredientes, menu, combos);
			
			ArrayList<Ingrediente> listaIngredientes = restaurante.getIngredientes();
			ArrayList<Combo> listaCombos = restaurante.getMenuCombos();
			ArrayList<ProductoMenu> listaProducto = restaurante.getMenuBase();
			
			//Revisar ingredientes
			
			assertEquals("lechuga", listaIngredientes.get(0).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(1000, listaIngredientes.get(0).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("tomate", listaIngredientes.get(1).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(1000, listaIngredientes.get(1).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");

			assertEquals("cebolla", listaIngredientes.get(2).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(1000, listaIngredientes.get(2).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("queso mozzarella", listaIngredientes.get(3).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(2500, listaIngredientes.get(3).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("huevo", listaIngredientes.get(4).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(2500, listaIngredientes.get(4).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("queso americano", listaIngredientes.get(5).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(2500, listaIngredientes.get(5).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("tocineta express", listaIngredientes.get(6).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(2500, listaIngredientes.get(6).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("papa callejera", listaIngredientes.get(7).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(2000, listaIngredientes.get(7).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("pepinillos", listaIngredientes.get(8).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(2500, listaIngredientes.get(8).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("cebolla grille", listaIngredientes.get(9).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(2500, listaIngredientes.get(9).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("suero costeño", listaIngredientes.get(10).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(3000, listaIngredientes.get(10).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("frijol refrito", listaIngredientes.get(11).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(4500, listaIngredientes.get(11).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("queso fundido", listaIngredientes.get(12).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(4500, listaIngredientes.get(12).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("tocineta picada", listaIngredientes.get(13).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(6000, listaIngredientes.get(13).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");
			
			assertEquals("piña", listaIngredientes.get(14).getNombre(), "Nombre de ingrediente cargado incorrectamente");
			assertEquals(2500, listaIngredientes.get(14).getCostoAdicional(), "Precio de ingrediente cargado incorrectamente");

			//Revisar productos
			
			assertEquals("corral", listaProducto.get(0).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(14000, listaProducto.get(0).getPrecio(), "Precio de producto cargado incorrectamente");

			assertEquals("corral queso", listaProducto.get(1).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(16000, listaProducto.get(1).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("corral pollo", listaProducto.get(2).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(15000, listaProducto.get(2).getPrecio(), "Precio de producto cargado incorrectamente");

			assertEquals("corralita", listaProducto.get(3).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(13000, listaProducto.get(3).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("todoterreno", listaProducto.get(4).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(25000, listaProducto.get(4).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("1/2 libra", listaProducto.get(5).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(25000, listaProducto.get(5).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("especial", listaProducto.get(6).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(24000, listaProducto.get(6).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("casera", listaProducto.get(7).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(23000, listaProducto.get(7).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("mexicana", listaProducto.get(8).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(22000, listaProducto.get(8).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("criolla", listaProducto.get(9).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(22000, listaProducto.get(9).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("costeña", listaProducto.get(10).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(20000, listaProducto.get(10).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("hawaiana", listaProducto.get(11).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(20000, listaProducto.get(11).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("wrap de pollo", listaProducto.get(12).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(15000, listaProducto.get(12).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("wrap de lomo", listaProducto.get(13).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(22000, listaProducto.get(13).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("ensalada mexicana", listaProducto.get(14).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(20900, listaProducto.get(14).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("papas medianas", listaProducto.get(15).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(5500, listaProducto.get(15).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("papas grandes", listaProducto.get(16).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(6900, listaProducto.get(16).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("papas en casco medianas", listaProducto.get(17).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(5500, listaProducto.get(17).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("papas en casco grandes", listaProducto.get(18).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(6900, listaProducto.get(18).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("agua cristal sin gas", listaProducto.get(19).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(5000, listaProducto.get(19).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("agua cristal con gas", listaProducto.get(20).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(5000, listaProducto.get(20).getPrecio(), "Precio de producto cargado incorrectamente");
			
			assertEquals("gaseosa", listaProducto.get(21).getNombre(), "Nombre de producto cargado incorrectamente");
			assertEquals(5000, listaProducto.get(21).getPrecio(), "Precio de producto cargado incorrectamente");
			
		//Revisar Combos
			
			assertEquals("combo corral", listaCombos.get(0).getNombre(), "Nombre de combo cargado incorrectamente");
			assertEquals(22050, listaCombos.get(0).getPrecio(), "Productos del combo cargados incorrectamente");
			
			assertEquals("combo corral queso", listaCombos.get(1).getNombre(), "Nombre de combo cargado incorrectamente");
			assertEquals(23850, listaCombos.get(1).getPrecio(), "Productos del combo cargados incorrectamente");
			
			assertEquals("combo todoterreno", listaCombos.get(2).getNombre(), "Nombre de combo cargado incorrectamente");
			assertEquals(34317, listaCombos.get(2).getPrecio(), "Productos del combo cargados incorrectamente");
			
			assertEquals("combo especial", listaCombos.get(3).getNombre(), "Nombre de combo cargado incorrectamente");
			assertEquals(31222, listaCombos.get(3).getPrecio(), "Productos del combo cargados incorrectamente");
		}
		

		
		catch(HamburguesaException e) {
			fail(e.getMessage());
		}
		
		catch (NumberFormatException e){
			
			fail("Información incorrecta en la carga");
			
		}	
		
		catch (IOException e){
			
			fail(e.getMessage());
			
		}	
		
			
	}
	
	@Test
	@DisplayName ("Probar pedido en curso")
	public void probarPedidoEnCurso() {
		
		try {
			restaurante.iniciarPedido("Martin Hernandez", "Cra 51A #127-49");
			
			assertEquals("Martin Hernandez", restaurante.getPedidoEnCurso().getNombreCliente(), "Pedido en curso erróneo");
			
			assertThrows(YaHayUnPedidoEnCursoException.class, () -> restaurante.iniciarPedido("Laura Rodríguez", "Hacienda Fontanar Casa 2"));
		} catch (YaHayUnPedidoEnCursoException e) {

		}
		
	}
	
	@Test
	@DisplayName("Probar Excepcion NoHayPedidoEnCurso")
	public void probarGuardarPedidoFalla() {
		
		assertThrows(NoHayPedidoEnCursoException.class, () -> restaurante.cerrarYGuardarPedido());
	}
	
	@Test
	@DisplayName("Probar guardar pedido correctamente")
	public void probarGuardarPedido() throws YaHayUnPedidoEnCursoException, NoHayPedidoEnCursoException, IOException {
		
		restaurante.iniciarPedido("Martin Hernandez", "Cra 51A #127-49");
		Pedido pedido = restaurante.getPedidoEnCurso();
		
		ProductoMenu corral = new ProductoMenu("corral queso", 16000);
		
		//Agregar un producto para que el pedido no sea vacio
		pedido.agregarProducto(corral);
		//Guardar la factura que deberia generar el pedido
		String facturaEsperada = pedido.generarTextoFactura();
		
		String idPedido = Integer.toString( pedido.getIdPedido());
		//cerrar pedido
		restaurante.cerrarYGuardarPedido();
		
		//verificar que ya no haya pedido en curso
		assertNull(restaurante.getPedidoEnCurso());
		//verificar que el pedido cerrado se haya añadido a la lista correspondiente
		assertEquals(1, restaurante.getPedidos().size());
		
		String facturaGuardada = new String(Files.readAllBytes(Paths.get("./facturas/factura_"+idPedido+".txt")));
		
		assertEquals(facturaEsperada, facturaGuardada, "Factura pedido guardada incorrectamente");
		
		
		
		
	}
	
	@Test
	@DisplayName("Probar Ingrediente Repetido")
	public void probarExcepcionIngredientes() throws NumberFormatException, HamburguesaException, IOException {
		File ingredientes = new File("./data/ingredientes.txt");	
		File combos = new File("./data/combos.txt");	
		File menu= new File("./data/menu.txt");
		
		Ingrediente lechuga = new Ingrediente("lechuga", 1000);
		
		restaurante.getIngredientes().add(lechuga);
		
		assertThrows(IngredienteRepetidoException.class, () -> restaurante.cargarInformacionRestaurante(ingredientes, menu, combos));
		

;
		
	}
	
	@Test
	@DisplayName("Probar Producto Repetido")
	public void probarExcepcionProductoRepetido() throws NumberFormatException, HamburguesaException, IOException {
		File ingredientes = new File("./data/ingredientes.txt");	
		File combos = new File("./data/combos.txt");	
		File menu= new File("./data/menu.txt");
		
		ProductoMenu corral = new ProductoMenu("corral", 14000);
		restaurante.getMenuBase().add(corral);
		assertThrows(ProductoRepetidoException.class, () -> restaurante.cargarInformacionRestaurante(ingredientes, menu, combos));
		
	}
	
	@Test
	@DisplayName("Probar Combo Repetido")
	
	public void probarComboRepetido() {
		File ingredientes = new File("./data/ingredientes.txt");	
		File combos = new File("./data/combos.txt");	
		File menu= new File("./data/menu.txt");
		
		ArrayList<ProductoMenu> listaDummy = new ArrayList<ProductoMenu>();
		Combo combo = new Combo("combo corral", 0.1, listaDummy);
		restaurante.getMenuCombos().add(combo);
		
		assertThrows(ProductoRepetidoException.class, () -> restaurante.cargarInformacionRestaurante(ingredientes, menu, combos));
		
		
	}
	
	@Test
	@DisplayName("Probar Producto Faltante Combo")
	
	public void probarProductoFaltante() {
		File ingredientes = new File("./data/ingredientes.txt");	
		File combos = new File("./data/combos.txt");
		//Se creo un duplicado del archivo de menu prueba, con la única diferencia que no tiene el produco "corral".
		//Esto permite probar la excepción de producto faltante durante la carga.
		File menu= new File("./data/menu_prueba.txt");
		
		assertThrows(ProductoFaltanteException.class, ()-> restaurante.cargarInformacionRestaurante(ingredientes, menu, combos));
		
	}
	
	
	
	
	
	
}
