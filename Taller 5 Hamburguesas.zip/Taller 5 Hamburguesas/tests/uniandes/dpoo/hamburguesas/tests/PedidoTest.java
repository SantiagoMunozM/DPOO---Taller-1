package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;



public class PedidoTest {
	
	private Pedido pedidoPrueba;
	
	@BeforeEach
	public void setUp() {
		
		Pedido.reestablecerContadorPedidos();
		pedidoPrueba = new Pedido("Martin Hernandez", "Carrera 51A #127-49");
		
		ProductoMenu hamburguesa = new ProductoMenu ("Corralísima", 25000);
		
		ProductoMenu papas = new ProductoMenu("Papas fritas", 7000);
		Ingrediente salsa = new Ingrediente("Salsa Mostaza", 1000);
		ProductoAjustado papasModificadas = new ProductoAjustado(papas);
		papasModificadas.agregarIngrediente(salsa);
		
		pedidoPrueba.agregarProducto(hamburguesa);
		pedidoPrueba.agregarProducto(papasModificadas);
		
		
	}
	
	@Test
	@DisplayName ("Prueba Constructor")
	public void pruebaConstructor() {
		assertEquals("Martin Hernandez", pedidoPrueba.getNombreCliente(), "Nombre guardado incorrectamente");
		assertEquals(1, pedidoPrueba.getIdPedido(), "ID pedido registrado incorrectamente");
	}
	
	@Test
	@DisplayName ("Prueba Precio Pedido")
	public void pruebaPrecioTotal() {
		
		assertEquals(39270, pedidoPrueba.getPrecioTotalPedido(), "Precio Calculado Incorrectamente");
		
	}
	
	
	@Test
	@DisplayName ("Prueba Generar Factura")
	public void pruebaFactura() {
		
		String facturaEsperada = "Cliente: Martin Hernandez\n"+
								 "Dirección: Carrera 51A #127-49\n"+
								 "----------------\n"+
								 "Corralísima\n"+"            25000\n"+
								 "Papas fritas\n"+
								 "    +Salsa Mostaza\n                1000\n"+
								 "            8000\n"+
								 "----------------\n"+
								 "Precio Neto:  33000\n"+
								 "IVA:          6270\n"+
								 "Precio Total: 39270\n";
		assertEquals(facturaEsperada, pedidoPrueba.generarTextoFactura(), "Factura Generada Incorrectamente");
		
	}
	
	@Test
	@DisplayName ("Guardar factura en carpeta que no existe")
	public void guardarFacturaFalla() {
		
		String archivoCarpeta = "./carpetaNoExiste/";
		String nombreArchivo = "factura_1.txt";
		
		File archivo = new File(archivoCarpeta+nombreArchivo);
		
		assertThrows(FileNotFoundException.class,() -> pedidoPrueba.guardarFactura(archivo));
	
	}
	
	@Test
	@DisplayName ("Factura Guardada Correctamente")
	public void verificarFacturaCorrecta() {
		
		File archivo = new File("./facturas/factura_2.txt");
		
		try {
			pedidoPrueba.guardarFactura(archivo);
			String facturaEsperada = pedidoPrueba.generarTextoFactura();
			String facturaGuardada = new String(Files.readAllBytes(Paths.get("./facturas/factura_2.txt")));
			
			assertEquals(facturaEsperada, facturaGuardada);
		}
		
		catch (IOException e) {
			
			 fail(e.getMessage());
			
		}
		
	}

}
