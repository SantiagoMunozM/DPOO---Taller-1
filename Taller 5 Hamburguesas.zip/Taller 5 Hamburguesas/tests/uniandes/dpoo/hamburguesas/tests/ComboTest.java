package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ComboTest {
	
	private Combo comboPrueba;
	
	
	
	@BeforeEach
	public void setUp() {
		
		ProductoMenu hamburguesa = new ProductoMenu("Todoterreno", 30000);
		ProductoMenu papas = new ProductoMenu("Papas a la francesa",7000);
		ProductoMenu bebida = new ProductoMenu("Coca Cola", 3000);
		
		ArrayList<ProductoMenu> productosCombo = new ArrayList<ProductoMenu>();
		productosCombo.add(bebida);
		productosCombo.add(hamburguesa);
		productosCombo.add(papas);
		
		comboPrueba = new Combo("Combo Todoterreno", 0.1, productosCombo);
		
		
	}
	
	@Test
	@DisplayName ("Prueba Constructor") 
	public void pruebaConstructor() {
		
		assertEquals(comboPrueba.getNombre(), "Combo Todoterreno", "Nombre guardado incorrectamente");
		assertEquals(comboPrueba.getPrecio(), 36000, "Precio inicial no concuerda con precios de productos y descuento");
		
		
	}
	
	@Test
	@DisplayName ("Prueba Factura")
	public void pruebaFactura() {
		String facturaGenerada = comboPrueba.generarTextoFactura();
		String facturaEsperada = "Combo Combo Todoterreno\n Descuento: 0.1\n            36000\n";
		assertEquals(facturaEsperada, facturaGenerada, "Factura generada incorrectamente");
	}
	
}
