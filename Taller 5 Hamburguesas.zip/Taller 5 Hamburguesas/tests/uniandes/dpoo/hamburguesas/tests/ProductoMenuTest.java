package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoMenuTest {
	
	private ProductoMenu producto;
	
	@BeforeEach
	public void setUp() {
		
		producto = new ProductoMenu("Todoterreno", 30000);
	}
	
	@Test
	@DisplayName("Prueba Constructor")
	public void pruebaConstructor() {
		
		assertEquals(producto.getNombre(), "Todoterreno", "Nombre guardado incorrectamente");
		assertEquals(producto.getPrecio(), 30000, "Precio guardado incorrecamente");
		
	}
	
	@Test
	@DisplayName ("Prueba Generar Factura")
	public void pruebaFactura(){
		String facturaGenerada = producto.generarTextoFactura();
		String facturaEsperada = "Todoterreno\n"+"            30000\n";
		assertEquals(facturaEsperada,facturaGenerada, "Factura generada incorrectamente");
	}
	
	
	
	

}
